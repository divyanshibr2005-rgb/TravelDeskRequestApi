using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using TravelDeskRequestApi.Controllers;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.Tests
{
    [TestFixture]
    public class RequestsTests
    {
        private Mock<IRequestsRepository> _requestRepoMock = null!;
        private TravelRequestsController _controller = null!;

        [SetUp]
        public void Setup()
        {
            _requestRepoMock = new Mock<IRequestsRepository>();
            _controller = new TravelRequestsController(_requestRepoMock.Object);
        }

        // ---------- GET ALL ----------
        [Test]
        public async Task GetAll_ReturnsOk_WithAllRequests()
        {
            // Arrange
            var requests = new List<TravelRequest>
            {
                new TravelRequest { RequestId = 1, ProjectName = "A" },
                new TravelRequest { RequestId = 2, ProjectName = "B" }
            };
            _requestRepoMock.Setup(r => r.GetAllRequests()).ReturnsAsync(requests);

            // Act
            var result = await _controller.GetAll(null, null);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result.Result!;
            Assert.That(ok.Value, Is.EqualTo(requests));
        }

        [Test]
        public async Task GetAll_WithEmployeeId_ReturnsFiltered()
        {
            // Arrange
            var filtered = new List<TravelRequest> { new TravelRequest { RequestId = 3 } };
            _requestRepoMock.Setup(r => r.GetRequestsByEmployee(6)).ReturnsAsync(filtered);

            // Act
            var result = await _controller.GetAll(employeeId: 6, assignedTo: null);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            Assert.That(((OkObjectResult)result.Result!).Value, Is.EqualTo(filtered));
        }

        [Test]
        public async Task GetAll_WithAssignedTo_ReturnsFiltered()
        {
            // Arrange
            var filtered = new List<TravelRequest> { new TravelRequest { RequestId = 4 } };
            _requestRepoMock.Setup(r => r.GetRequestsAssignedTo(7)).ReturnsAsync(filtered);

            // Act
            var result = await _controller.GetAll(employeeId: null, assignedTo: 7);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            Assert.That(((OkObjectResult)result.Result!).Value, Is.EqualTo(filtered));
        }

        // ---------- GET BY ID ----------
        [Test]
        public async Task GetById_ReturnsOk_WithRequest()
        {
            // Arrange
            var req = new TravelRequest { RequestId = 10, ProjectName = "Trip" };
            _requestRepoMock.Setup(r => r.GetRequestById(10)).ReturnsAsync(req);

            // Act
            var result = await _controller.GetById(10);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            Assert.That(((OkObjectResult)result.Result!).Value, Is.EqualTo(req));
        }

        [Test]
        public async Task GetById_NotFound_ReturnsNotFound()
        {
            // Arrange
            _requestRepoMock.Setup(r => r.GetRequestById(It.IsAny<int>())).ReturnsAsync((TravelRequest?)null);

            // Act
            var result = await _controller.GetById(123);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<NotFoundResult>().Or.InstanceOf<NotFoundObjectResult>());
        }

        // ---------- CREATE ----------
        [Test]
        public async Task Create_ReturnsCreatedAtAction()
        {
            // Arrange
            var request = new TravelRequest { ProjectName = "New Trip" };
            _requestRepoMock.Setup(r => r.AddRequest(It.IsAny<TravelRequest>())).ReturnsAsync(99);
            _requestRepoMock.Setup(r => r.GetRequestById(99)).ReturnsAsync(new TravelRequest { RequestId = 99, ProjectName = "New Trip" });

            // Act
            var result = await _controller.Create(request);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<CreatedAtActionResult>());
            var created = (CreatedAtActionResult)result.Result!;
            Assert.That(((TravelRequest)created.Value!).RequestId, Is.EqualTo(99));
        }

        // ---------- UPDATE (PUT) ----------
        [Test]
        public async Task Update_ReturnsNoContent_OnSuccess()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 20 };
            var update = new TravelRequest { RequestId = 20 };
            _requestRepoMock.Setup(r => r.GetRequestById(20)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateRequest(update)).ReturnsAsync(true);

            // Act
            var result = await _controller.Update(20, update);

            // Assert
            Assert.That(result, Is.InstanceOf<NoContentResult>());
        }

        [Test]
        public async Task Update_ReturnsBadRequest_OnIdMismatch()
        {
            // Arrange
            var request = new TravelRequest { RequestId = 2 };
            // Act
            var result = await _controller.Update(1, request);
            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
        }

        [Test]
        public async Task Update_ReturnsNotFound_WhenMissing()
        {
            // Arrange
            _requestRepoMock.Setup(r => r.GetRequestById(30)).ReturnsAsync((TravelRequest?)null);
            var update = new TravelRequest { RequestId = 30 };

            // Act
            var result = await _controller.Update(30, update);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>().Or.InstanceOf<NotFoundObjectResult>());
        }

        [Test]
        public async Task Update_Returns500_OnRepositoryFailure()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 40 };
            var update = new TravelRequest { RequestId = 40 };
            _requestRepoMock.Setup(r => r.GetRequestById(40)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateRequest(update)).ReturnsAsync(false);

            // Act
            var result = await _controller.Update(40, update);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            Assert.That(((ObjectResult)result).StatusCode, Is.EqualTo(500));
        }

        // ---------- PATCH ----------
        [Test]
        public async Task Patch_ReturnsOk_WhenStatusUpdated()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 50 };
            _requestRepoMock.Setup(r => r.GetRequestById(50)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(50, "NewStatus", null)).ReturnsAsync(true);

            var body = new TravelRequestsController.UpdateStatusDto("NewStatus", null);
            // Act
            var result = await _controller.Patch(50, body);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(50, "NewStatus", null), Times.Once);
        }

        [Test]
        public async Task Patch_ReturnsOk_WhenAssignedToUpdated()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 51, AssignedTo = null };
            _requestRepoMock.Setup(r => r.GetRequestById(51)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateRequest(It.IsAny<TravelRequest>())).ReturnsAsync(true);

            var body = new TravelRequestsController.UpdateStatusDto(null, 123);
            // Act
            var result = await _controller.Patch(51, body);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateRequest(It.Is<TravelRequest>(t => t.AssignedTo == 123)), Times.Once);
        }

        [Test]
        public async Task Patch_ReturnsBadRequest_WhenNothingToUpdate()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 52 };
            _requestRepoMock.Setup(r => r.GetRequestById(52)).ReturnsAsync(existing);

            var body = new TravelRequestsController.UpdateStatusDto(null, null);
            // Act
            var result = await _controller.Patch(52, body);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>().Or.InstanceOf<BadRequestResult>());
        }

        [Test]
        public async Task Patch_ReturnsNotFound_WhenMissing()
        {
            // Arrange
            _requestRepoMock.Setup(r => r.GetRequestById(53)).ReturnsAsync((TravelRequest?)null);
            var body = new TravelRequestsController.UpdateStatusDto("x", null);

            // Act
            var result = await _controller.Patch(53, body);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>().Or.InstanceOf<NotFoundObjectResult>());
        }

        [Test]
        public async Task Patch_Returns500_WhenUpdateFails()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 54 };
            _requestRepoMock.Setup(r => r.GetRequestById(54)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(54, "S", null)).ReturnsAsync(false);

            var body = new TravelRequestsController.UpdateStatusDto("S", null);
            // Act
            var result = await _controller.Patch(54, body);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            Assert.That(((ObjectResult)result).StatusCode, Is.EqualTo(500));
        }

        // ---------- DELETE ----------
        [Test]
        public async Task Delete_ReturnsNoContent_OnSuccess()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 60 };
            _requestRepoMock.Setup(r => r.GetRequestById(60)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.DeleteRequest(60)).ReturnsAsync(true);

            // Act
            var result = await _controller.Delete(60);

            // Assert
            Assert.That(result, Is.InstanceOf<NoContentResult>());
        }

        [Test]
        public async Task Delete_ReturnsNotFound_WhenMissing()
        {
            // Arrange
            _requestRepoMock.Setup(r => r.GetRequestById(61)).ReturnsAsync((TravelRequest?)null);

            // Act
            var result = await _controller.Delete(61);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>().Or.InstanceOf<NotFoundObjectResult>());
        }

        [Test]
        public async Task Delete_Returns500_OnFailure()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 62 };
            _requestRepoMock.Setup(r => r.GetRequestById(62)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.DeleteRequest(62)).ReturnsAsync(false);

            // Act
            var result = await _controller.Delete(62);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            Assert.That(((ObjectResult)result).StatusCode, Is.EqualTo(500));
        }

        // ---------- HANDLE ACTIONS ----------
        [Test]
        public async Task HandleAction_Submit_ReturnsBadRequest_WhenManagerMissing()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 70 };
            _requestRepoMock.Setup(r => r.GetRequestById(70)).ReturnsAsync(existing);

            var action = new TravelRequestsController.ActionDto("Submit", TargetUserId: null, HrAdminUserId: null, ManagerUserId: null);
            // Act
            var result = await _controller.HandleAction(70, action);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>().Or.InstanceOf<BadRequestResult>());
        }

        [Test]
        public async Task HandleAction_Approve_CallsUpdateStatusAndReturnsOk()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 71 };
            _requestRepoMock.Setup(r => r.GetRequestById(71)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(71, It.IsAny<string>(), It.IsAny<int?>())).ReturnsAsync(true);

            var action = new TravelRequestsController.ActionDto("Approve", TargetUserId: 55);
            // Act
            var result = await _controller.HandleAction(71, action);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(71, It.Is<string>(s => s == "ManagerApproved"), 55), Times.Once);
        }

        [Test]
        public async Task HandleAction_Reject_SetsRejectedAndReturnsOk()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 72 };
            _requestRepoMock.Setup(r => r.GetRequestById(72)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(72, "Rejected", null)).ReturnsAsync(true);

            var action = new TravelRequestsController.ActionDto("Reject", TargetUserId: null);
            // Act
            var result = await _controller.HandleAction(72, action);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(72, "Rejected", null), Times.Once);
        }

        [Test]
        public async Task HandleAction_ReturnToEmployee_ReturnsOk()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 73 };
            _requestRepoMock.Setup(r => r.GetRequestById(73)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(73, "ReturnedToEmployee", 99)).ReturnsAsync(true);

            var action = new TravelRequestsController.ActionDto("ReturnToEmployee", TargetUserId: 99);
            // Act
            var result = await _controller.HandleAction(73, action);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(73, "ReturnedToEmployee", 99), Times.Once);
        }

        [Test]
        public async Task HandleAction_SetHrProcessing_UsesAssignedTo()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 74, AssignedTo = 200 };
            _requestRepoMock.Setup(r => r.GetRequestById(74)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(74, "TravelAdminProcessing", 200)).ReturnsAsync(true);

            var action = new TravelRequestsController.ActionDto("SetHrProcessing", TargetUserId: null);
            // Act
            var result = await _controller.HandleAction(74, action);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(74, "TravelAdminProcessing", 200), Times.Once);
        }

        [Test]
        public async Task HandleAction_Close_ReturnsOk()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 75 };
            _requestRepoMock.Setup(r => r.GetRequestById(75)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(75, "Completed", null)).ReturnsAsync(true);

            var action = new TravelRequestsController.ActionDto("Close", TargetUserId: null);
            // Act
            var result = await _controller.HandleAction(75, action);

            // Assert
            Assert.That(result, Is.InstanceOf<OkResult>());
            _requestRepoMock.Verify(r => r.UpdateStatus(75, "Completed", null), Times.Once);
        }

        [Test]
        public async Task HandleAction_UnknownAction_ReturnsBadRequest()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 76 };
            _requestRepoMock.Setup(r => r.GetRequestById(76)).ReturnsAsync(existing);

            var action = new TravelRequestsController.ActionDto("DoSomethingWeird", TargetUserId: null);
            // Act
            var result = await _controller.HandleAction(76, action);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>().Or.InstanceOf<BadRequestResult>());
        }

        [Test]
        public async Task HandleAction_Returns500_WhenUpdateStatusFails()
        {
            // Arrange
            var existing = new TravelRequest { RequestId = 77 };
            _requestRepoMock.Setup(r => r.GetRequestById(77)).ReturnsAsync(existing);
            _requestRepoMock.Setup(r => r.UpdateStatus(77, "ManagerApproved", 88)).ReturnsAsync(false);

            var action = new TravelRequestsController.ActionDto("Approve", TargetUserId: 88);
            // Act
            var result = await _controller.HandleAction(77, action);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            Assert.That(((ObjectResult)result).StatusCode, Is.EqualTo(500));
        }
    }
}