using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using TravelDeskRequestApi.Controllers;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace TravelDeskRequestApi.Tests
{
    [TestFixture]
    public class DocumentsTests
    {
        private Mock<IDocumentsRepository> _repoMock = null!;
        private Mock<IWebHostEnvironment> _envMock = null!;
        private IConfiguration _config = null!;
        private DocumentsController _controller = null!;

        // Use a temp storage root to avoid touching real app folders
        private string _tempStorageRoot = null!;

        [SetUp]
        public void Setup()
        {
            _repoMock = new Mock<IDocumentsRepository>();
            _envMock = new Mock<IWebHostEnvironment>();

            // Create a unique temp directory for this test run
            _tempStorageRoot = Path.Combine(Path.GetTempPath(), "DocsTests_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_tempStorageRoot);

            // Configuration: DocumentStoragePath points to our temp dir
            var inMemorySettings = new Dictionary<string, string?>
            {
                { "DocumentStoragePath", _tempStorageRoot }
            };
            _config = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            // If controller falls back to env.ContentRootPath (not used here), return temp path
            _envMock.Setup(e => e.ContentRootPath).Returns(_tempStorageRoot);

            _controller = new DocumentsController(_repoMock.Object, _envMock.Object, _config);
        }

        [TearDown]
        public void Cleanup()
        {
            try
            {
                if (Directory.Exists(_tempStorageRoot))
                    Directory.Delete(_tempStorageRoot, recursive: true);
            }
            catch
            {
                // ignore cleanup errors
            }
        }

        // ---------- Helpers ----------

        private static IFormFile MakeFormFile(string fileName, string content = "dummy")
        {
            var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(content));
            return new FormFile(stream, 0, stream.Length, "file", fileName)
            {
                Headers = new HeaderDictionary(),
                ContentType = "application/octet-stream"
            };
        }

        private static Document MakeDocument(int uid = 1, int requestId = 101, string? documentType = "passport", IFormFile? file = null)
        {
            return new Document
            {
                Uid = uid,
                RequestId = requestId,
                DocumentType = documentType ?? "",
                File = file
            };
        }

        // ---------- UPLOAD ----------

        [Test]
        public async Task Upload_ReturnsBadRequest_WhenNoFile()
        {
            // Arrange
            var doc = MakeDocument(file: null);

            // Act
            var result = await _controller.Upload(doc);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            var bad = (BadRequestObjectResult)result;
            Assert.That(bad.Value, Is.EqualTo("No file uploaded."));
        }

        [Test]
        public async Task Upload_ReturnsBadRequest_WhenDocumentTypeEmpty()
        {
            // Arrange
            var doc = MakeDocument(documentType: "", file: MakeFormFile("a.pdf"));

            // Act
            var result = await _controller.Upload(doc);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            var bad = (BadRequestObjectResult)result;
            Assert.That(bad.Value, Is.EqualTo("DocumentType is required."));
        }

        [Test]
        public async Task Upload_ReturnsBadRequest_WhenDocumentTypeInvalid()
        {
            // Arrange
            var doc = MakeDocument(documentType: "invalid_type", file: MakeFormFile("a.pdf"));

            // Act
            var result = await _controller.Upload(doc);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            var bad = (BadRequestObjectResult)result;
            Assert.That(bad.Value, Is.EqualTo("DocumentType must be one of: aadhar, passport, visa."));
        }

        [Test]
        public async Task Upload_Success_ReturnsCreatedAtAction_WithSavedDocument()
        {
            // Arrange
            var input = MakeDocument(documentType: "  PASSPORT  ", file: MakeFormFile("doc.pdf"));

            // repo should return new ID and then object by ID
            _repoMock.Setup(r => r.AddDocument(It.IsAny<Document>())).ReturnsAsync(123);
            _repoMock.Setup(r => r.GetDocumentById(123)).ReturnsAsync(new Document
            {
                DocumentId = 123,
                Uid = input.Uid,
                RequestId = input.RequestId,
                DocumentType = "passport", // expected lowercased
                FileName = "doc.pdf",
                FilePath = "any/path" // controller sets actual path
            });

            // Act
            var result = await _controller.Upload(input);

            // Assert
            Assert.That(result, Is.InstanceOf<CreatedAtActionResult>());
            var created = (CreatedAtActionResult)result;
            Assert.That(created.ActionName, Is.EqualTo(nameof(DocumentsController.GetById)));
            Assert.That(created.RouteValues?["id"], Is.EqualTo(123));
            Assert.That(created.Value, Is.InstanceOf<Document>());

            // Also verify the repo was called with a Document having normalized type and filename/path set
            _repoMock.Verify(r => r.AddDocument(It.Is<Document>(d =>
                d.DocumentType == "passport" &&
                d.FileName == "doc.pdf" &&
                !string.IsNullOrWhiteSpace(d.FilePath)
            )), Times.Once);
        }

        // ---------- GET BY ID ----------

        [Test]
        public async Task GetById_ReturnsOk_WhenFound()
        {
            // Arrange
            var doc = new Document { DocumentId = 11, Uid = 1, RequestId = 101, DocumentType = "visa" };
            _repoMock.Setup(r => r.GetDocumentById(11)).ReturnsAsync(doc);

            // Act
            var result = await _controller.GetById(11);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result.Result!;
            Assert.That(ok.Value, Is.EqualTo(doc));
        }

        [Test]
        public async Task GetById_ReturnsNotFound_WhenMissing()
        {
            // Arrange
            _repoMock.Setup(r => r.GetDocumentById(99)).ReturnsAsync((Document?)null);

            // Act
            var result = await _controller.GetById(99);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<NotFoundResult>());
        }

        // ---------- GET BY REQUEST ----------

        [Test]
        public async Task GetByRequest_ReturnsOk_WithList()
        {
            // Arrange
            var list = new List<Document>
            {
                new Document { DocumentId = 1, RequestId = 200, DocumentType = "aadhar" },
                new Document { DocumentId = 2, RequestId = 200, DocumentType = "passport" }
            };
            _repoMock.Setup(r => r.GetDocumentsByRequest(200)).ReturnsAsync(list);

            // Act
            var result = await _controller.GetByRequest(200);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result.Result!;
            Assert.That(ok.Value, Is.EqualTo(list));
        }

        // ---------- DELETE ----------

        [Test]
        public async Task Delete_ReturnsNotFound_WhenDocumentMissing()
        {
            // Arrange
            _repoMock.Setup(r => r.GetDocumentById(50)).ReturnsAsync((Document?)null);

            // Act
            var result = await _controller.Delete(50);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>());
        }

        [Test]
        public async Task Delete_Success_NoContent_AndFileDeleted()
        {
            // Arrange: create a real file to delete
            var filePath = Path.Combine(_tempStorageRoot, "to_delete.txt");
            await File.WriteAllTextAsync(filePath, "temp", CancellationToken.None);

            var doc = new Document { DocumentId = 77, FilePath = filePath };
            _repoMock.Setup(r => r.GetDocumentById(77)).ReturnsAsync(doc);
            _repoMock.Setup(r => r.DeleteDocument(77)).ReturnsAsync(true);

            // Act
            var result = await _controller.Delete(77);

            // Assert
            Assert.That(result, Is.InstanceOf<NoContentResult>());
            Assert.That(File.Exists(filePath), Is.False, "File should be deleted.");
            _repoMock.Verify(r => r.DeleteDocument(77), Times.Once);
        }

        [Test]
        public async Task Delete_RepoFailure_Returns500()
        {
            // Arrange
            var doc = new Document { DocumentId = 88, FilePath = null };
            _repoMock.Setup(r => r.GetDocumentById(88)).ReturnsAsync(doc);
            _repoMock.Setup(r => r.DeleteDocument(88)).ReturnsAsync(false);

            // Act
            var result = await _controller.Delete(88);

            // Assert
            Assert.That(result, Is.InstanceOf<ObjectResult>());
            var obj = (ObjectResult)result;
            Assert.That(obj.StatusCode, Is.EqualTo(500));
            Assert.That(obj.Value, Is.EqualTo("Failed to delete document."));
        }
    }
}
