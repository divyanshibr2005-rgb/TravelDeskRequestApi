﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TravelRequestsController : ControllerBase
    {
        private readonly IRequestsRepository _repo;

        public TravelRequestsController(IRequestsRepository repo)
        {
            _repo = repo;
        }

        // Keep string constants for minimal change; consider converting to enum later
        private static class RequestStatus
        {
            public const string Draft = "Draft";
            public const string Submitted = "Submitted";
            public const string ManagerApproved = "ManagerApproved";
            public const string Rejected = "Rejected";
            public const string ReturnedToEmployee = "ReturnedToEmployee";
            public const string ReturnedToManager = "ReturnedToManager";
            public const string TravelAdminProcessing = "TravelAdminProcessing";
            public const string Completed = "Completed";
        }

        // DTOs
        public record CreateRequestDto([Required] string Purpose, int? EmployeeId, string? Status);
        public record UpdateRequestDto(int RequestId, string? Purpose, int? AssignedTo, string? Status);
        public record ActionDto([Required] string Action, int? TargetUserId = null, int? HrAdminUserId = null, int? ManagerUserId = null);
        public record UpdateStatusDto(string? Status, int? AssignedTo);

        // GET: api/travelrequests
        // Support optional filters to reduce number of endpoints:
        // - ?employeeId=6
        // - ?assignedTo=3
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TravelRequest>>> GetAll([FromQuery] int? employeeId, [FromQuery] int? assignedTo)
        {
            if (employeeId.HasValue)
            {
                var byEmployee = await _repo.GetRequestsByEmployee(employeeId.Value);
                return Ok(byEmployee);
            }

            if (assignedTo.HasValue)
            {
                var byAssigned = await _repo.GetRequestsAssignedTo(assignedTo.Value);
                return Ok(byAssigned);
            }

            var items = await _repo.GetAllRequests();
            return Ok(items);
        }

        // GET: api/travelrequests/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<TravelRequest>> GetById(int id)
        {
            var item = await _repo.GetRequestById(id);
            return item is null ? NotFound() : Ok(item);
        }

        // POST: api/travelrequests
        [HttpPost]
        public async Task<ActionResult<TravelRequest>> Create([FromBody] TravelRequest request)
        {
            request.Status ??= RequestStatus.Draft;

            var newId = await _repo.AddRequest(request);
            var created = await _repo.GetRequestById(newId);
            return CreatedAtAction(nameof(GetById), new { id = newId }, created);
        }

        // PUT: api/travelrequests/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] TravelRequest request)
        {
            if (id != request.RequestId)
                return BadRequest("ID in route and body do not match.");

            var exists = await _repo.GetRequestById(id);
            if (exists is null)
                return NotFound();

            var ok = await _repo.UpdateRequest(request);
            return ok ? NoContent() : StatusCode(500, "Failed to update travel request.");
        }

        // PATCH: api/travelrequests/5
        // Partial updates (preferred for small state changes like status/assignedTo)
        [HttpPatch("{id:int}")]
        public async Task<IActionResult> Patch(int id, [FromBody] UpdateStatusDto body)
        {
            var exists = await _repo.GetRequestById(id);
            if (exists is null) return NotFound();

            // Only allow updating status and/or assigned user here.
            if (body.Status is null && body.AssignedTo is null)
                return BadRequest("Nothing to update.");

            // If status provided, update via repository UpdateStatus for consistency
            if (body.Status is not null)
            {
                var ok = await _repo.UpdateStatus(id, body.Status, body.AssignedTo);
                return ok ? Ok() : StatusCode(500, "Failed to update status.");
            }

            // If only AssignedTo provided, perform a lightweight update
            if (body.AssignedTo is not null)
            {
                exists.AssignedTo = body.AssignedTo;
                var ok = await _repo.UpdateRequest(exists);
                return ok ? Ok() : StatusCode(500, "Failed to update assignment.");
            }

            return BadRequest();
        }

        // DELETE: api/travelrequests/5
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var exists = await _repo.GetRequestById(id);
            if (exists is null)
                return NotFound();

            var ok = await _repo.DeleteRequest(id);
            return ok ? NoContent() : StatusCode(500, "Failed to delete travel request.");
        }

        // Unified command/action endpoint:
        // POST: api/travelrequests/{id}/action
        // body: { "action":"Approve", "targetUserId":123, "hrAdminUserId":456, "managerUserId":789 }
        [HttpPost("{id:int}/action")]
        public async Task<IActionResult> HandleAction(int id, [FromBody] ActionDto body)
        {
            var exists = await _repo.GetRequestById(id);
            if (exists is null) return NotFound();

            var action = body.Action?.Trim();
            if (string.IsNullOrWhiteSpace(action))
                return BadRequest("Action cannot be empty.");

            int? targetUserId = body.TargetUserId ?? body.HrAdminUserId ?? body.ManagerUserId;

            string newStatus;
            switch (action.ToLowerInvariant())
            {
                case "submit":
                    newStatus = RequestStatus.Submitted;
                    if (body.ManagerUserId is null && body.TargetUserId is null)
                        return BadRequest("Submit requires 'managerUserId'.");
                    targetUserId = body.ManagerUserId ?? body.TargetUserId;
                    break;

                case "approve":
                    newStatus = RequestStatus.ManagerApproved;
                    if (targetUserId is null)
                        return BadRequest("Approve requires 'hrAdminUserId' (or 'targetUserId').");
                    break;

                case "reject":
                    newStatus = RequestStatus.Rejected;
                    targetUserId = null;
                    break;

                case "returntoemployee":
                case "return-to-employee":
                case "return_to_employee":
                    newStatus = RequestStatus.ReturnedToEmployee;
                    if (targetUserId is null)
                        return BadRequest("Returning to employee requires 'targetUserId'.");
                    break;

                case "returntomanager":
                case "return-to-manager":
                case "return_to_manager":
                    newStatus = RequestStatus.ReturnedToManager;
                    if (targetUserId is null)
                        return BadRequest("Returning to manager requires 'targetUserId'.");
                    break;

                case "sethrprocessing":
                case "hr-processing":
                case "hrprocessing":
                    newStatus = RequestStatus.TravelAdminProcessing;
                    targetUserId = exists.AssignedTo;
                    break;

                case "close":
                    newStatus = RequestStatus.Completed;
                    targetUserId = null;
                    break;

                default:
                    return BadRequest("Unknown action. Allowed: Submit, Approve, Reject, ReturnToEmployee, ReturnToManager, SetHrProcessing, Close.");
            }

            var ok = await _repo.UpdateStatus(id, newStatus, targetUserId);
            return ok ? Ok() : StatusCode(500, "Failed to update status.");
        }
    }
}