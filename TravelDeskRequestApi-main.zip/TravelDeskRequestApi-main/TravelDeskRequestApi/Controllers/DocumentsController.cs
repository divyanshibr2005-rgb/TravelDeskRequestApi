using Microsoft.AspNetCore.Mvc;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class DocumentsController : ControllerBase
	{
		private readonly IDocumentsRepository _repo;
		private readonly IWebHostEnvironment _env;
		private readonly IConfiguration _config;

		public DocumentsController(IDocumentsRepository repo, IWebHostEnvironment env, IConfiguration config)
		{
			_repo = repo;
			_env = env;
			_config = config;
		}

		// POST: api/documents/upload
		// multipart/form-data with fields: uid(int), requestId(int), documentType(string), file (IFormFile)
		[HttpPost("upload")]
		public async Task<IActionResult> Upload([FromForm] Document doc)
		{
			if (doc.File is null) return BadRequest("No file uploaded.");
			if (string.IsNullOrWhiteSpace(doc.DocumentType)) return BadRequest("DocumentType is required.");

			// sanitize doc type
			var dt = doc.DocumentType.Trim().ToLowerInvariant();
			if (dt != "aadhar" && dt != "passport" && dt != "visa")
				return BadRequest("DocumentType must be one of: aadhar, passport, visa.");

			var storageRoot = _config.GetValue<string>("DocumentStoragePath") ?? Path.Combine(_env.ContentRootPath, "uploads");
			if (!Directory.Exists(storageRoot)) Directory.CreateDirectory(storageRoot);

			var fileName = Path.GetFileName(doc.File.FileName);
			var unique = $"{Guid.NewGuid():N}_{fileName}";
			var destPath = Path.Combine(storageRoot, unique);

			await using (var fs = System.IO.File.Create(destPath))
			{
				await doc.File.CopyToAsync(fs);
			}

			doc.FileName = fileName;
			doc.FilePath = destPath.Replace("\\", "/");
			doc.DocumentType = dt;

			var newId = await _repo.AddDocument(doc);
			var created = await _repo.GetDocumentById(newId);
			return CreatedAtAction(nameof(GetById), new { id = newId }, created);
		}

		[HttpGet("{id:int}")]
		public async Task<ActionResult<Document>> GetById(int id)
		{
			var d = await _repo.GetDocumentById(id);
			return d is null ? NotFound() : Ok(d);
		}

		[HttpGet("byrequest/{requestId:int}")]
		public async Task<ActionResult<IEnumerable<Document>>> GetByRequest(int requestId)
		{
			var list = await _repo.GetDocumentsByRequest(requestId);
			return Ok(list);
		}

		[HttpDelete("{id:int}")]
		public async Task<IActionResult> Delete(int id)
		{
			var d = await _repo.GetDocumentById(id);
			if (d is null) return NotFound();

			// delete file if exists
			try
			{
				if (!string.IsNullOrWhiteSpace(d.FilePath) && System.IO.File.Exists(d.FilePath))
				{
					System.IO.File.Delete(d.FilePath);
				}
			}
			catch
			{
				// ignore file delete errors
			}

			var ok = await _repo.DeleteDocument(id);
			return ok ? NoContent() : StatusCode(500, "Failed to delete document.");
		}
	}
}