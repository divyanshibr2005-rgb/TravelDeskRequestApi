﻿using System;

namespace TravelDeskRequestApi.Models
{
    public class TravelRequest
    {
        public int RequestId { get; set; }

        // Who raised it / who currently handles it
        public int EmployeeId { get; set; }
        public int? AssignedTo { get; set; }

        // Core fields
        public string? ProjectName { get; set; }
        public string? DepartmentName { get; set; }
        public string? ReasonForTravel { get; set; }

        public string? BookingType { get; set; }       // Air / Hotel / Both
        public bool? IsInternational { get; set; }

        public string? AadhaarNumber { get; set; }
        public string? PassportNumber { get; set; }

        // File paths (nullable)
        public string? PassportFilePath { get; set; }
        public string? VisaFilePath { get; set; }

        // Dates / stay details
        public DateTime? TravelDate { get; set; }
        public DateTime? HotelStartDate { get; set; }
        public int? DaysOfStay { get; set; }

        // Meals
        public string? MealRequired { get; set; }      // Lunch / Dinner / Both
        public string? MealPreference { get; set; }    // Veg / Non-Veg

        // Workflow
        public string? Status { get; set; }            // Draft / Submitted / ManagerApproved / Rejected / ReturnedToEmployee / ReturnedToManager / TravelAdminProcessing / Completed

        // Audit
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
