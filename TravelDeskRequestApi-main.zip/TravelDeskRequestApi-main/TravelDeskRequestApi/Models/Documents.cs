using System;
using Microsoft.AspNetCore.Http;

namespace TravelDeskRequestApi.Models
{
    public class Document
    {
        public int DocumentId { get; set; }

        // Foreign keys
        public int Uid { get; set; }
        public int RequestId { get; set; }

        // document_type: 'aadhar'|'passport'|'visa'
        public string DocumentType { get; set; } = null!;

        // Stored file info
        // Make nullable so model binding does not require these when uploading; controller will populate them.
        public string? FileName { get; set; }
        public string? FilePath { get; set; }

        public DateTime UploadedAt { get; set; }

        // Not persisted: used for uploads
        public IFormFile? File { get; set; }
    }
}