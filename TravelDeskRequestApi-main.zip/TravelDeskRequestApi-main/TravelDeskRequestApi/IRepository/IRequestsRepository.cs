﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.IRepository
{
    public interface IRequestsRepository
    {
        // Basic Reads
        Task<IEnumerable<TravelRequest>> GetAllRequests();
        Task<TravelRequest?> GetRequestById(int requestId);
        Task<IEnumerable<TravelRequest>> GetRequestsByEmployee(int employeeId);
        Task<IEnumerable<TravelRequest>> GetRequestsAssignedTo(int userId);

        // Create / Update / Delete
        Task<int> AddRequest(TravelRequest request);
        Task<bool> UpdateRequest(TravelRequest request);
        Task<bool> DeleteRequest(int requestId);

        // Minimal workflow helpers
        Task<bool> UpdateStatus(int requestId, string status, int? assignedTo);
    }
}
