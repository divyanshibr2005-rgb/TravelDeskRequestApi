using System.Collections.Generic;
using System.Threading.Tasks;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.IRepository
{
	public interface IDocumentsRepository
	{
		Task<int> AddDocument(Document doc);
		Task<Document?> GetDocumentById(int documentId);
		Task<IEnumerable<Document>> GetDocumentsByRequest(int requestId);
		Task<bool> DeleteDocument(int documentId);
	}
}