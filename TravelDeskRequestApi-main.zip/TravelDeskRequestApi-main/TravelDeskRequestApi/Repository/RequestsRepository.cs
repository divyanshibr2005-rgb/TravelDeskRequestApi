﻿using Dapper;
using MySqlConnector;
using System.Data;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.Repository
{
    public class RequestsRepository : IRequestsRepository
    {
        private readonly string _connectionString;

        public RequestsRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        private IDbConnection CreateConnection() => new MySqlConnection(_connectionString);

        // -------------------- SELECTS --------------------

        public async Task<IEnumerable<TravelRequest>> GetAllRequests()
        {
            const string sql = @"
                SELECT
                    request_id         AS RequestId,
                    employee_id        AS EmployeeId,
                    assigned_to        AS AssignedTo,
                    project_name       AS ProjectName,
                    department_name    AS DepartmentName,
                    reason_for_travel  AS ReasonForTravel,
                    booking_type       AS BookingType,
                    is_international   AS IsInternational,
                    aadhaar_number     AS AadhaarNumber,
                    passport_number    AS PassportNumber,
                    passport_file_path AS PassportFilePath,
                    visa_file_path     AS VisaFilePath,
                    travel_date        AS TravelDate,
                    hotel_start_date   AS HotelStartDate,
                    days_of_stay       AS DaysOfStay,
                    meal_required      AS MealRequired,
                    meal_preference    AS MealPreference,
                    status             AS Status,
                    created_on         AS CreatedOn,
                    updated_on         AS UpdatedOn
                FROM travel_requests
                ORDER BY created_on DESC;";
            using var connection = CreateConnection();
            return await connection.QueryAsync<TravelRequest>(sql);
        }

        public async Task<TravelRequest?> GetRequestById(int requestId)
        {
            const string sql = @"
                SELECT
                    request_id         AS RequestId,
                    employee_id        AS EmployeeId,
                    assigned_to        AS AssignedTo,
                    project_name       AS ProjectName,
                    department_name    AS DepartmentName,
                    reason_for_travel  AS ReasonForTravel,
                    booking_type       AS BookingType,
                    is_international   AS IsInternational,
                    aadhaar_number     AS AadhaarNumber,
                    passport_number    AS PassportNumber,
                    passport_file_path AS PassportFilePath,
                    visa_file_path     AS VisaFilePath,
                    travel_date        AS TravelDate,
                    hotel_start_date   AS HotelStartDate,
                    days_of_stay       AS DaysOfStay,
                    meal_required      AS MealRequired,
                    meal_preference    AS MealPreference,
                    status             AS Status,
                    created_on         AS CreatedOn,
                    updated_on         AS UpdatedOn
                FROM travel_requests
                WHERE request_id = @RequestId;";
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<TravelRequest>(sql, new { RequestId = requestId });
        }

        public async Task<IEnumerable<TravelRequest>> GetRequestsByEmployee(int employeeId)
        {
            const string sql = @"
                SELECT
                    request_id         AS RequestId,
                    employee_id        AS EmployeeId,
                    assigned_to        AS AssignedTo,
                    project_name       AS ProjectName,
                    department_name    AS DepartmentName,
                    reason_for_travel  AS ReasonForTravel,
                    booking_type       AS BookingType,
                    is_international   AS IsInternational,
                    aadhaar_number     AS AadhaarNumber,
                    passport_number    AS PassportNumber,
                    passport_file_path AS PassportFilePath,
                    visa_file_path     AS VisaFilePath,
                    travel_date        AS TravelDate,
                    hotel_start_date   AS HotelStartDate,
                    days_of_stay       AS DaysOfStay,
                    meal_required      AS MealRequired,
                    meal_preference    AS MealPreference,
                    status             AS Status,
                    created_on         AS CreatedOn,
                    updated_on         AS UpdatedOn
                FROM travel_requests
                WHERE employee_id = @EmployeeId
                ORDER BY created_on DESC;";
            using var connection = CreateConnection();
            return await connection.QueryAsync<TravelRequest>(sql, new { EmployeeId = employeeId });
        }

        public async Task<IEnumerable<TravelRequest>> GetRequestsAssignedTo(int userId)
        {
            const string sql = @"
                SELECT
                    request_id         AS RequestId,
                    employee_id        AS EmployeeId,
                    assigned_to        AS AssignedTo,
                    project_name       AS ProjectName,
                    department_name    AS DepartmentName,
                    reason_for_travel  AS ReasonForTravel,
                    booking_type       AS BookingType,
                    is_international   AS IsInternational,
                    aadhaar_number     AS AadhaarNumber,
                    passport_number    AS PassportNumber,
                    passport_file_path AS PassportFilePath,
                    visa_file_path     AS VisaFilePath,
                    travel_date        AS TravelDate,
                    hotel_start_date   AS HotelStartDate,
                    days_of_stay       AS DaysOfStay,
                    meal_required      AS MealRequired,
                    meal_preference    AS MealPreference,
                    status             AS Status,
                    created_on         AS CreatedOn,
                    updated_on         AS UpdatedOn
                FROM travel_requests
                WHERE assigned_to = @AssignedTo
                ORDER BY updated_on DESC;";
            using var connection = CreateConnection();
            return await connection.QueryAsync<TravelRequest>(sql, new { AssignedTo = userId });
        }

        // -------------------- INSERT --------------------

        public async Task<int> AddRequest(TravelRequest request)
        {
            const string sql = @"
                INSERT INTO travel_requests
                (
                    employee_id, assigned_to, project_name, department_name, reason_for_travel,
                    booking_type, is_international, aadhaar_number, passport_number,
                    passport_file_path, visa_file_path,
                    travel_date, hotel_start_date, days_of_stay,
                    meal_required, meal_preference, status, created_on, updated_on
                )
                VALUES
                (
                    @EmployeeId, @AssignedTo, @ProjectName, @DepartmentName, @ReasonForTravel,
                    @BookingType, @IsInternational, @AadhaarNumber, @PassportNumber,
                    @PassportFilePath, @VisaFilePath,
                    @TravelDate, @HotelStartDate, @DaysOfStay,
                    @MealRequired, @MealPreference, @Status, NOW(), NOW()
                );
                SELECT LAST_INSERT_ID();";
            using var connection = CreateConnection();
            return await connection.ExecuteScalarAsync<int>(sql, request);
        }

        // -------------------- UPDATE --------------------

        public async Task<bool> UpdateRequest(TravelRequest request)
        {
            const string sql = @"
                UPDATE travel_requests
                SET
                    employee_id        = @EmployeeId,
                    assigned_to        = @AssignedTo,
                    project_name       = @ProjectName,
                    department_name    = @DepartmentName,
                    reason_for_travel  = @ReasonForTravel,
                    booking_type       = @BookingType,
                    is_international   = @IsInternational,
                    aadhaar_number     = @AadhaarNumber,
                    passport_number    = @PassportNumber,
                    passport_file_path = @PassportFilePath,
                    visa_file_path     = @VisaFilePath,
                    travel_date        = @TravelDate,
                    hotel_start_date   = @HotelStartDate,
                    days_of_stay       = @DaysOfStay,
                    meal_required      = @MealRequired,
                    meal_preference    = @MealPreference,
                    status             = @Status,
                    updated_on         = NOW()
                WHERE request_id = @RequestId;";
            using var connection = CreateConnection();
            var rowsAffected = await connection.ExecuteAsync(sql, request);
            return rowsAffected > 0;
        }

        public async Task<bool> UpdateStatus(int requestId, string status, int? assignedTo)
        {
            const string sql = @"
                UPDATE travel_requests
                SET status = @Status,
                    assigned_to = @AssignedTo,
                    updated_on = NOW()
                WHERE request_id = @RequestId;";
            using var connection = CreateConnection();
            var rowsAffected = await connection.ExecuteAsync(sql, new { RequestId = requestId, Status = status, AssignedTo = assignedTo });
            return rowsAffected > 0;
        }

        // -------------------- DELETE --------------------

        public async Task<bool> DeleteRequest(int requestId)
        {
            const string sql = "DELETE FROM travel_requests WHERE request_id = @RequestId;";
            using var connection = CreateConnection();
            var rowsAffected = await connection.ExecuteAsync(sql, new { RequestId = requestId });
            return rowsAffected > 0;
        }
    }
}