using Dapper;
using MySqlConnector;
using System.Data;
using TravelDeskRequestApi.IRepository;
using TravelDeskRequestApi.Models;

namespace TravelDeskRequestApi.Repository
{
    public class DocumentsRepository : IDocumentsRepository
    {
        private readonly string _connectionString;

        public DocumentsRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        private IDbConnection CreateConnection() => new MySqlConnection(_connectionString);

        public async Task<int> AddDocument(Document doc)
        {
            const string sql = @"
                INSERT INTO documents
                (uid, request_id, document_type, file_name, file_path, uploaded_at)
                VALUES
                (@Uid, @RequestId, @DocumentType, @FileName, @FilePath, NOW());
                SELECT LAST_INSERT_ID();";
            using var conn = CreateConnection();
            return await conn.ExecuteScalarAsync<int>(sql, doc);
        }

        public async Task<Document?> GetDocumentById(int documentId)
        {
            const string sql = @"
                SELECT
                    document_id AS DocumentId,
                    uid AS Uid,
                    request_id AS RequestId,
                    document_type AS DocumentType,
                    file_name AS FileName,
                    file_path AS FilePath,
                    uploaded_at AS UploadedAt
                FROM documents
                WHERE document_id = @DocumentId;";
            using var conn = CreateConnection();
            return await conn.QueryFirstOrDefaultAsync<Document>(sql, new { DocumentId = documentId });
        }

        public async Task<IEnumerable<Document>> GetDocumentsByRequest(int requestId)
        {
            const string sql = @"
                SELECT
                    document_id AS DocumentId,
                    uid AS Uid,
                    request_id AS RequestId,
                    document_type AS DocumentType,
                    file_name AS FileName,
                    file_path AS FilePath,
                    uploaded_at AS UploadedAt
                FROM documents
                WHERE request_id = @RequestId
                ORDER BY uploaded_at DESC;";
            using var conn = CreateConnection();
            return await conn.QueryAsync<Document>(sql, new { RequestId = requestId });
        }

        public async Task<bool> DeleteDocument(int documentId)
        {
            const string sql = "DELETE FROM documents WHERE document_id = @DocumentId;";
            using var conn = CreateConnection();
            var rows = await conn.ExecuteAsync(sql, new { DocumentId = documentId });
            return rows > 0;
        }
    }
}